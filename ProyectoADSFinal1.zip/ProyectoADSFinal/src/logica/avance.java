/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

/**

 */
public class avance {
    
    private int semestre;
    private String codigo;
    private String nff;
    private String nombre;
    private int creditos;
    private String profesor;
    private String nota;
    
    public avance (String codigo, String nff, String nombre, int creditos, String profesor, String nota){
        this.semestre = semestre;
        this.codigo = codigo;
        this.nff = nff;
        this.nombre = nombre;
        this.creditos = creditos;
        this.profesor = profesor;
        this.nota = nota;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNff(String nff) {
        this.nff = nff;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }

    
    
    public int getSemestre() {
        return semestre;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNff() {
        return nff;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public String getProfesor() {
        return profesor;
    }

    public String getNota() {
        return nota;
    }
}
