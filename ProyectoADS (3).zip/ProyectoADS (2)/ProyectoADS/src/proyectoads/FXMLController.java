/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package proyectoads;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author Felipe
 */
public class FXMLController implements Initializable {

    @FXML
    private Button btnConsulta;
    @FXML
    private Button btnPensum;
    @FXML
    private Button btnAvance;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnConsultaAccion(ActionEvent event) {
    }

    @FXML
    private void btnPensumAccion(ActionEvent event) {
    }

    @FXML
    private void btnAvanceAccion(ActionEvent event) {
    }
    
}
