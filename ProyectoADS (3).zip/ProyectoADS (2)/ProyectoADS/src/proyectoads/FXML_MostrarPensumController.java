/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package proyectoads;

import Logica.Clases;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.stage.Modality;

import logica.*;

/**
 * FXML Controller class
 *
 * @author Felipe
 */
public class FXML_MostrarPensumController implements Initializable {

    @FXML
    private ComboBox<String> ComboBoxSemestre;
    @FXML
    private ComboBox<?> comboBoxMateria;
    @FXML
    private Button btnBuscar;
    @FXML
    private Text creditos;
    private Label canCreditos;
    @FXML
    private Text nff;
    private Label nombreNff;
    private Label numCodigo;
    @FXML
    private Text codigo;
    FXMLController prueba;
    @FXML
    private Label LblCanCreditos;
    @FXML
    private Label LblNombreNff;
    @FXML
    private Label LblNumCodigo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ComboBoxSemestre.setItems(FXCollections.observableArrayList("1","2","3","4","5","6","7","8"));
        this.ComboBoxSemestre.setVisible(true);
        this.btnBuscar.setVisible(true);
        this.comboBoxMateria.setVisible(false);
        this.creditos.setVisible(false);
        this.canCreditos.setVisible(false);
        this.codigo.setVisible(false);
        this.numCodigo.setVisible(false);
        this.nff.setVisible(false);
        this.nombreNff.setVisible(false);
        
        ArrayList<Object> materias = new ArrayList<>();
        
        Clases asig1 = new Clases(1295, "Nucleo de Formacion fundamental Ciencias Basicas","Calculo Diferencial",3);
        Clases asig2 = new Clases(33518, "Nucleo de Formacion fundamental Ciencias Basicas","Logica y Matematicas Discretas",3);
        Clases asig3 = new Clases(33698, "Nucleo de Formacion fundamental Ingenieria Aplicada","Intro a la Programacion",3);
        Clases asig4 = new Clases(4075, "Nucleo de Formacion fundamental Ingenieria Aplicada","Pensamiento Sistemico",3);
        Clases asig5 = new Clases(33763, "Nucleo de Formacion fundamental Ingenieria Aplicada","Introduccion a la ingenieria",2);
        Clases asig6 = new Clases(34809, "Nucleo de Formacion fundamental Ingenieria Aplicada","Fundamentos Seguridad de la Informacion",2);
        Clases asig7 = new Clases(1297, "Nucleo de Formacion fundamental Ciencias Basica","Calculo Integral",3);
        Clases asig8 = new Clases(1290, "Nucleo de Formacion fundamental Ciencias Basica","Algebra Lineal",3);
        Clases asig9 = new Clases(33699, "Nucleo de Formacion fundamental Ingenieria Aplicada","Programacion Avanzada",3);
        Clases asig10 = new Clases(34816, "Nucleo de Formacion fundamental Ingenieria Aplicada","Gestion Financiera en Proyectos TI",2);
        Clases asig11 = new Clases(33733, "Nucleo de Formacion fundamental Ingenieria Aplicada","Proyecto de Diseño en Ingenieria",2);
        Clases asig12= new Clases(34580, "Nucleo de Formacion fundamental Ingenieria Aplicada","Arquitectura y Organizacion del computador",2);
        Clases asig13= new Clases(33732, "Nucleo de Formacion fundamental Ciencias Basicas","Probabilidad y Estadica",3);
        Clases asig14= new Clases(33700, "Nucleo de Formacion fundamental Ingenieria Aplicada","Bases de Datos",4);
        Clases asig15= new Clases(34805, "Nucleo de Formacion fundamental Ingenieria Aplicada","Analisis y Diseño de SW",3);
        Clases asig16= new Clases(4190, "Nucleo de Formacion fundamental Ingenieria Aplicada","Comunicaciones y Redes",4);
        Clases asig17= new Clases(2544, "Nucleo de Formación Fundamental Socio-Humanística","Significacion Teologica",2);
        Clases asig18= new Clases(4196, "Nucleo de Formación Fundamental Ingenieria Aplicada","Estructuras de Datos",3);
        Clases asig19= new Clases(4082, "Nucleo de Formación Fundamental Ingenieria Aplicada","Sistemas de Informacion",3);
        Clases asig20= new Clases(34803, "Nucleo de Formación Fundamental Ingenieria Aplicada","Gestion de Proy. de Inn y Emprendimiento de TI",3);
        Clases asig21= new Clases(34806, "Nucleo de Formación Fundamental Ingenieria Aplicada","Fundamentos de Ingenieria de Software",3);
        Clases asig22= new Clases(4085, "Nucleo de Formación Fundamental Ingenieria Aplicada","Sistemas Operativos",3);
        Clases asig23= new Clases(1299, "Nucleo de Formación Fundamental Ciencias Basicas","Calculo Vectorial",3);
        Clases asig24= new Clases(34801, "Nucleo de Formación Fundamental Ingenieria Aplicada","Teoria de la Computacion",2);
        Clases asig25= new Clases(34810, "Nucleo de Formación Fundamental Ingenieria Aplicada","Proyecto Innovacion y Emprendimiento",3);
        Clases asig26= new Clases(22586, "Nucleo de Formación Fundamental Ingenieria Aplicada","Intro. Sistemas Distribuidos",2);
        Clases asig27= new Clases(1340, "Nucleo de Formación Fundamental Ciencias Basicas","Fisica Mecanica",3);
        Clases asig28= new Clases(1300, "Nucleo de Formación Fundamental Ciencias Basicas","Ecuaciones Diferenciales",3);
        Clases asig29= new Clases(34866, "Nucleo de Formación Fundamental Ingenieria Aplicada","Opti y Simulacion",2);
        Clases asig30= new Clases(3194, "Nucleo de Formación Fundamental Ingenieria Aplicada","Analisis de Algoritmos",2);
        Clases asig31= new Clases(34808, "Nucleo de Formación Fundamental Ingenieria Aplicada","Introduccion a la Computacion Movil",2);
        Clases asig32= new Clases(2476, "Nucleo de Formación Fundamental Socio-Humanística","Fe y Compromiso del Ingeniero",2);
        Clases asig33= new Clases(1291, "Nucleo de Formación Fundamental Ciencias Basicas","Analisis Numerico",3);
        Clases asig34= new Clases(4084, "Nucleo de Formación Fundamental Ingenieria Aplicada","Intro Inteligencia Artificial",3);
        Clases asig35= new Clases(4185, "Nucleo de Formación Fundamental Ingenieria Aplicada","Arquitectura Software",3);
        Clases asig36= new Clases(5100, "Nucleo de Formación Fundamental Socio-Humanística","Proyecto Social Universitario",2);
        Clases asig37= new Clases(34863, "Nucleo de Formación Fundamental Socio-Humanística","Etica en la Era de la Informacion",2);
        Clases asig38= new Clases(34802, "Nucleo de Formación Fundamental Ingenieria Aplicada","Tecnologias Digitales Emergentes",2);
        Clases asig39= new Clases(34804, "Nucleo de Formación Fundamental Ingenieria Aplicada","Gerencia Estrategica de TI",2);
        Clases asig40= new Clases(16143, "Nucleo de Formación Fundamental Socio-Humanística","Constitucion y Derecho Civil",2);
        Clases asig41= new Clases(2356, "Nucleo de Formación Fundamental Socio-Humanística","Epistemologia de la ingenieria",2);
        
        materias.add(asig1);
        materias.add(asig2);
        materias.add(asig3);
        materias.add(asig4);
        materias.add(asig5);
        materias.add(asig6);
        materias.add(asig7);
        materias.add(asig8);
        materias.add(asig9);
        materias.add(asig10);
        materias.add(asig11);
        materias.add(asig12);
        materias.add(asig13);
        materias.add(asig14);
        materias.add(asig15);
        materias.add(asig16);
        materias.add(asig17);
        materias.add(asig18);
        materias.add(asig19);
        materias.add(asig20);
        materias.add(asig21);
        materias.add(asig22);
        materias.add(asig23);
        materias.add(asig24);
        materias.add(asig25);
        materias.add(asig26);
        materias.add(asig27);
        materias.add(asig28);
        materias.add(asig29);
        materias.add(asig30);
        materias.add(asig31);
        materias.add(asig32);
        materias.add(asig33);
        materias.add(asig34);
        materias.add(asig35);
        materias.add(asig36);
        materias.add(asig37);
        materias.add(asig38);
        materias.add(asig39);
        materias.add(asig40);
        materias.add(asig41);
        
    }    

    @FXML
    private void ComboBoxSemestreAccion(ActionEvent event) {
        String semEscogido = this.ComboBoxSemestre.getSelectionModel().getSelectedItem();
        switch(semEscogido){
            case "1"->{
                comboBoxMateria.setVisible(true);
                btnBuscar.setVisible(true);
                comboBoxMateria.setItems(FXCollection.observableArrayList("Calculo Diferencial","Logica y Matematicas Discretas","Introduccion a la Programacion","Pensamiento Sistemico","Introduccion a la Ingenieria","Fundamentos Seguridad de la Informacion"));
            }

            case "2"->{
                comboBoxMateria.setVisible(true);
                btnBuscar.setVisible(true);
                    comboBoxMateria.setItems(FXCollection.observableArrayList("Calculo Integral","Algebra lineal","Programacion Avanzada","Gestion Financiera de Proyectos de TI","Proyectos de Diseño en Ingenieria","Arquitectura y Organizacion del Computador"));
                }

                case "3"->{
                    comboBoxMateria.setVisible(true);
                    btnBuscar.setVisible(true);
                    comboBoxMateria.setItems(FXCollection.observableArrayList("Probabilidad y Estadistica","Base de Datos","Analisis y Diseño de Software","Comunicaciones y Redes"));
                }

                case "4"->{
                        comboBoxMateria.setVisible(true);
                        btnBuscar.setVisible(true);
                        comboBoxMateria.setItems(FXCollection.observableArrayList("Estructuras de Datos","Sistemas de Informacion","Gestion de Proyectos de Innovaciony Emprendimiento en TI","Fundamentos Ingenieria de Software","Sistemas Operativos"));
                }

                case "5"->{
                    comboBoxMateria.setVisible(true);
                    btnBuscar.setVisible(true);
                    comboBoxMateria.setItems(FXCollection.observableArrayList("Calculo Vectorial","Teoria de la Computacion","Proyecto de Innovacion y Emprendimiento","Induccion a los Sistemas Distribuidos"));
                }

                case "6"->{
                        comboBoxMateria.setVisible(true);
                        btnBuscar.setVisible(true);
                        comboBoxMateria.setItems(FXCollection.observableArrayList("Fisica Mecanica","Ecuaciones Diferenciales","Optimizacion y Simulacion","Analisis de Algoritmos","Desarrollo Web","Introduccion a la Computacion Movil","Fe y Compromiso del Ingeniero"));
                }

                case "7"->{
                        
                    comboBoxMateria.setVisible(true);
                    btnBuscar.setVisible(true);
                    comboBoxMateria.setItems(FXCollection.observableArrayList("Analisis Numerico","Introduccion a la Inteligencia Artificial","Arquitectura de Software","Proyecto Social Universitario","Etica en la Era de la Informacion"));
                }

                case "8"->{
                    comboBoxMateria.setVisible(true);
                    btnBuscar.setVisible(true);
                    comboBoxMateria.setItems(FXCollection.observableArrayList("Electiva de Ciencias Basicas","Tecnologias Digitales Emergentes","Gerencia Estrategia de TI","Constitucion y Derecho Civil","Epistemologa de la Ingenieria"));
                }
            }
        
        }
    @FXML
    private void comboBoxMateriaAction(ActionEvent event) {
    }

    @FXML
    private void btnBuscarAction(ActionEvent event) {
        
    }
    
}
