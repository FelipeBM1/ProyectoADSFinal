/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package proyectoads;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author Felipe
 */
public class FXML_AvanceEstudianteController implements Initializable {
    
    @FXML
    private ComboBox<String> ComboBoxSemestre;
    @FXML
    private ComboBox<String> ComboBoxMateria;
    @FXML
    private Label LblInformacionNota;
    @FXML
    private Label LblInformacionProfesor;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    
    ObservableList<String>ComboBoxSemestreList = FXCollections.observableArrayList("1","2","3","4","5","6","7","8");
    @FXML
    private Button btnConsultar;
    
    @FXML private void ComboBoxSemestreAccion(ActionEvent event) {
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ComboBoxSemestre.setItems(ComboBoxSemestreList);
        ComboBoxSemestre.setItems(FXCollections.observableArrayList("1","2","3","4","5","6","7","8"));
        
            
    }

    @FXML
    private void ComboBoxMateriaAction(ActionEvent event) {
    }

    @FXML
    private void btnConsultarAction(ActionEvent event) {
    }

    
    
   
}
         

