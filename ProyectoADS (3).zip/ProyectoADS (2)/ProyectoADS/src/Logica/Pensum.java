/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import java.io.IOException;

/**
 *
 * @author vianr
 */
public class Pensum {
    private int semestre;
    private int codigo;
    private String nff;
    private String nombre;
    private int creditos;
    
    public Pensum (int semestre, int codigo, String nff, String nombre, int creditos){
        this.semestre = semestre;
        this.codigo = codigo;
        this.nff = nff;
        this.nombre = nombre;
        this.creditos = creditos;
    }
    
}
