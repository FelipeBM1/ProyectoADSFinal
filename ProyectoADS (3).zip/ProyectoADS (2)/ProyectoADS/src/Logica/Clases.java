/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

/**
 *
 * @author vianr
 */
public class Clases {
    private int semestre;
    private int codigo;
    private String nff;
    private String nombre;
    private int creditos;
    private String profesor;
    private double nota;
    
    public Clases (int semestre, int codigo, String nff, String nombre, int creditos, String profesor, double nota){
        this.semestre = semestre;
        this.codigo = codigo;
        this.nff = nff;
        this.nombre = nombre;
        this.creditos = creditos;
        this.profesor = profesor;
        this.nota = nota;
    }

    public Clases(int i, String nucleo_de_Formacion_fundamental_Ciencias_, String calculo_Diferencial, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
