/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package proyectoads;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author Felipe
 */
public class FXML_AvanceEstudianteController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
      asignaturas = new ArrayList <> ();

Nucleo asig1 = new Nucleo(1295, "Nucleo de Formacion fundamental Ciencias Basicas","Calculo Diferencial",3,"Hector Orlando Linares Gonzalez",4.3);
Nucleo asig2 = new Nucleo(33518, "Nucleo de Formacion fundamental Ciencias Basicas","Logica y Matematicas Discretas",3,"Ismael Garcia Martin",4.5);
Nucleo asig3 = new Nucleo(33698, "Nucleo de Formacion fundamental Ingenieria Aplicada","Intro a la Programacion",3,"Guillermo Alejandro Cristancho Delgado",4.1);
Nucleo asig4 = new Nucleo(4075, "Nucleo de Formacion fundamental Ingenieria Aplicada","Pensamiento Sistemico",3,"Juan Erasmo Gómez Morantes",3.9);
Nucleo asig5 = new Nucleo(33763, "Nucleo de Formacion fundamental Ingenieria Aplicada","Introduccion a la ingenieria",2,"Jose Fernando Cardona Gomez",4.0);
Nucleo asig6 = new Nucleo(34809, "Nucleo de Formacion fundamental Ingenieria Aplicada","Fundamentos Seguridad de la Informacion",2,"Martha Liliana Sanchez Lozano",3.9);
Nucleo asig7 = new Nucleo(1297, "Nucleo de Formacion fundamental Ciencias Basica","Calculo Integral",3,"Sergio Eduardo Calvo Mazuera",4.1);
Nucleo asig8 = new Nucleo(1290, "Nucleo de Formacion fundamental Ciencias Basica","Algebra Lineal",3,"Juan Sebastián Gaitán Escarpeta",3.7);
Nucleo asig9 = new Nucleo(33699, "Nucleo de Formacion fundamental Ingenieria Aplicada","Programacion Avanzada",3,"Camilo Andres Canon Correa",4.5);
Nucleo asig10 = new Nucleo(34816, "Nucleo de Formacion fundamental Ingenieria Aplicada","Gestion Financiera en Proyectos TI",2,"Hugo Ignacio Baron Fernandez",3.7);
Nucleo asig11 = new Nucleo(33733, "Nucleo de Formacion fundamental Ingenieria Aplicada","Proyecto de Diseño en Ingenieria",2,"Alexander Cardenas Ramos",3.1);
Nucleo asig12= new Nucleo(34580, "Nucleo de Formacion fundamental Ingenieria Aplicada","Arquitectura y Organizacion del computador",2,"Cristian Javier Diaz Alvarez",3.5);
    }    
}
